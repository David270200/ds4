Public Class Perro
    Public nombre As String
    Public raza As String
    Public altura As String

    Public Function comer(carne As String) As String
        Return nombre + " mide " + altura + "y comer�" + carne
    End Function
    Public Sub Dormir()

    End Sub
    Public Sub Ladrar()
    End Sub
    Public Function calcularCosto(costo As Double, impuesto As Double) As Double
        Dim preciototal As Double
        preciototal = costo + (costo * impuesto)
        Return preciototal
    End Function

    Public Sub New()

    End Sub

    Public Sub New(nombre As String, raza As String, altura As String)
        Me.nombre = nombre
        Me.raza = raza
        Me.altura = altura
    End Sub
End Class

Public Module Program
    Public Sub Main(args() As String)

        Dim perrito As Perro = New Perro()
        perrito.nombre = "chizu"
        perrito.raza = "Pastor Alem�n"
        perrito.altura = "0.70cm"

        Console.WriteLine(perrito.comer(" carne"))

        Dim perrito2 As Perro = New Perro()
        perrito2.nombre = "Lasy"
        perrito2.altura = "0.60cm"

        Console.WriteLine(perrito2.comer(" pollo"))

        Dim perrito3 As Perro = New Perro("Peluchin", "Poodle", "0.50")

        Console.WriteLine(perrito3.comer(" Pan"))
    End Sub
End Module